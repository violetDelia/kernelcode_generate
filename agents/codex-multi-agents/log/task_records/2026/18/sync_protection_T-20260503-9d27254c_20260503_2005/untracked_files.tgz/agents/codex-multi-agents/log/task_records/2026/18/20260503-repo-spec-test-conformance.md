# 20260503-repo-spec-test-conformance

## 任务信息

- 任务：`repo-spec-test-conformance`
- 类型：`execute`
- 计划书：`ARCHITECTURE/plan/repo_spec_test_conformance_green_plan.md`
- worktree：`/home/lfr/kernelcode_generate/wt-20260503-repo-spec-test-conformance`

## 记录

- 待执行人按计划书 `S1-S5` 补齐规格、实现、测试与验收闭环。

时间：2026-05-03 13:59 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：按 `ARCHITECTURE/plan/repo_spec_test_conformance_green_plan.md` 的 S1-S5 一次完成全仓 `spec/test/实现` 一致性收口，跑通 pytest collect/full、`kernel_gen` coverage `95/70`、静态扫描归档和 `expectation` diff empty。
改动：执行前阅读已完成：已重新读取个人提示词、仓库 `AGENTS.md`、`agents/standard/协作执行通用规则.md`、`agents/standard/实现文件规范.md`、`agents/standard/测试文件约定.md`、`agents/standard/spec文件规范.md`、`agents/standard/任务记录约定.md`、`agents/standard/expectation任务规则.md`；已从主仓读取已通过三方复评的计划书正文。当前 worktree 内缺少 `ARCHITECTURE/plan/repo_spec_test_conformance_green_plan.md`，主仓根目录存在同名计划书；本轮先按该已通过计划正文推进，并把该现场差异记录为执行前异常。
验证：`rg -n "金铲铲大作战|execute|S1|dma_memory_hierarchy|KernelCodeError|operation" TODO.md` 在主仓命中 `T-20260503-9d27254c`；`git status --short` 于 worktree 显示仅任务记录目录未跟踪；尚未修改 `expectation/.skills/agents/standard/TODO/DONE`。
自检：当前执行口径已确认：人员元信息不再作为强制项；计划级流程为 `execute -> review -> 架构复核 / 终验 -> merge/归档`，review 或架构不通过均回 execute；`expectation` 只有当前计划列为必过资产才阻断，本计划默认只要求 `git diff --name-only -- expectation` 为空；后续持续检查跨文件非公开 API、测试直连非 API、`object` 签名、ctx 能力探测和非装饰器嵌套函数。
结论：进入 S1 基线盘点；公开 API 冲突、必须修改 `expectation` 或必须调整禁止修改面时暂停并写待确认项。

时间：2026-05-03 14:16 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：按计划书 S1-S5 做全仓 `spec/test/实现` 一致性收口，并跑通 collect/full pytest、`kernel_gen` coverage `95/70`、静态扫描分类和 `expectation` diff empty。
改动：
- `spec/execute_engine/execute_engine_api.md`：补齐 `ExecuteRequest.args` 对 `RuntimeInput` 内存输入公开形态的描述，明确覆盖 `torch.Tensor` / `numpy.ndarray` / `int` / `float`，修复 `test/script/test_requirements_txt.py` 对 requirements 依赖映射的真实失败；未改公开签名。
- `kernel_gen/dsl/ast/nodes/nn.py`：去掉本文件内部 reduce helper 注解中的泛化 `object`，改为本文件内 `TypeAlias`；`_contiguous_stride_attrs` 本地变量改为 `int | str`，不新增公开 API，不跨文件调用非公开 helper。
- `test/dsl/ast/nodes/test_nn.py`：撤掉对 `NnReduceAST.keepdim_value()` 这类实现 helper 的直接测试，改为通过公开 AST 属性与结果内存行为验证。
- `test/dsl/ast/nodes/test_dma.py`：测试本地子类 `emit_mlir` 返回注解从 `object` 收窄为公开 xDSL `SSAValue`。
- `test/dsl/ast/test_mlir_gen.py`：旧 `globals` / `builtins` 入参负例改为 `**{"globals": ...}` / `**{"builtins": ...}`，继续只验证公开 `mlir_gen(...)` 对已删除公开参数的稳定拒绝行为，不恢复旧参数。
- `test/dsl/gen_kernel/test_gen_kernel.py`、`test/dsl/gen_kernel/emit/test_package.py`、`spec/dsl/gen_kernel/emit*.md`、`spec/dialect/dma.md`、`spec/include/cpu/cpu.md`：清理 `build_func_op` 旧链路文字，统一成当前 `mlir_gen -> pass -> gen_kernel/emit_c` 口径；保留 `build_func_op` 作为包根不可达的负向边界说明，不把它写回公开 API。
验证：
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest --collect-only -q test`：退出 `0`，`1469 tests collected in 3.36s`，1 条 xDSL deprecation warning。
- 初始 `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test`：退出 `1`，`test/script/test_requirements_txt.py::test_requirements_txt_covers_execute_engine_memory_arg_dependencies` 失败，原因是 `spec/execute_engine/execute_engine_api.md` 未出现 `torch.Tensor`。
- 修复后 `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test` 通过证据来自 coverage 全量执行：`1469 passed, 24 warnings in 313.46s`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/script/test_requirements_txt.py`：退出 `0`，`3 passed in 0.01s`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/nodes/test_nn.py test/dsl/ast/nodes/test_dma.py`：退出 `0`，`10 passed, 1 warning`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/test_mlir_gen.py -k 'globals_cannot_replace_runtime_args or rejects_builtins_external_value_reference'`：退出 `0`，`2 passed, 38 deselected, 1 warning`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/gen_kernel/test_gen_kernel.py -k 'lowered_nn_add or compiles_and_runs_lowered_nn_add_variants_on_cpu'`：退出 `0`，`4 passed, 66 deselected, 1 warning`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/gen_kernel/emit/test_package.py -k test_emit_c_op_lowers_mlir_gen_nn_add_variants_after_pass`：退出 `0`，`1 passed, 54 deselected, 1 warning`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/test_package.py test/dsl/ast/test_package.py`：退出 `0`，`5 passed, 1 warning`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. python3 -m compileall -q kernel_gen/dsl/ast/nodes/nn.py test/dsl/ast/nodes/test_nn.py test/dsl/ast/nodes/test_dma.py test/dsl/ast/test_mlir_gen.py test/dsl/gen_kernel/emit/test_package.py`：退出 `0`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch -m pytest -q test`：退出 `0`，`1469 passed, 24 warnings in 313.46s`。
- `PYTHONDONTWRITEBYTECODE=1 coverage json -o coverage/repo_spec_test_conformance/coverage.json`：退出 `0`，已生成 `coverage/repo_spec_test_conformance/coverage.json`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. python3 script/check_python_coverage.py --coverage-json coverage/repo_spec_test_conformance/coverage.json --include-module kernel_gen --line-min 95 --branch-min 70`：退出 `1`，失败摘要为 `kernel_gen (131 file(s)): line coverage 78.44% < 95.00%; branch coverage 61.93% < 70.00%`。
- `git diff --name-only -- expectation`：退出 `0`，输出为空，确认未修改 `expectation/`。
- `git diff -- test | rg -n "collect_ignore|pytest_ignore_collect|skip\\(|xfail|pytest\\.mark\\.skip|pytest\\.mark\\.xfail"`：退出 `1`，无命中，确认测试 diff 未新增收集隐藏或 skip/xfail。
- `rg -n "collect_ignore|pytest_ignore_collect|spec_from_file_location|expectation\\." test`：退出 `1`，无命中。
- `rg -n "hasattr\\([^)]*ctx|getattr\\([^)]*ctx" test kernel_gen script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `1`，无命中。
- `rg -n "def [A-Za-z0-9_]+\\([^)]*: object|-> object" kernel_gen test script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `1`，无命中。
- `rg -n "from kernel_gen\\..* import .*_[A-Za-z]|kernel_gen\\.[A-Za-z0-9_.]*\\._[A-Za-z]" test script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `0`，仍有命中；本轮 diff 涉及的命中均归档为公开模块路径含下划线的误报、公开入口导入或包根负向边界测试，未发现本轮新增跨文件非公开 API 直连。
- `rg -n "globals=|builtins=|build_func_op|open-kind" test spec kernel_gen script main.py skills/codex-multi-agents/scripts -g "*.py" -g "*.md"`：退出 `0`，剩余 `open-kind` 为当前 tuning 公开合同；`build_func_op` 仅保留在包根不可达负向测试和 `spec/dsl/__init__.md` 非公开 API 边界说明中；本轮已清理 gen_kernel/emit/dma/include 相关旧链路文字。
- `rg -n "importlib\\.(import_module|util\\.find_spec)|exec\\(|eval\\(|monkeypatch|patch\\(" test kernel_gen script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `0`，剩余命中归档为公开模块导入、`from ... import *` 公开导出边界测试、公开 API monkeypatch / subprocess monkeypatch 或旧路径不可达边界；本轮未新增对非公开项目 API 的 monkeypatch。
- 嵌套 `def` AST 扫描：退出 `0`，命中主要为装饰器实现闭包、测试本地 DSL kernel 函数、测试本地 monkeypatch stub 和 pipeline 记录 stub；本轮修改测试中的嵌套函数属于公开 `mlir_gen` / `gen_kernel` 输入 fixture，不是跨文件 helper。
- `git diff -- pytest.ini pyproject.toml setup.cfg tox.ini .coveragerc spec script test kernel_gen | rg -n "addopts|testpaths|markers|filterwarnings|norecursedirs|collect_ignore|pytest_ignore_collect|line-min|branch-min|coverage_omit|python_coverage_omit|omit|--include-module|95|70"`：退出 `0`，仅命中 diff hunk 行号 / index 文本误报；本轮未修改 pytest / coverage 配置、coverage omit、阈值或 include 范围。
Diff 反推自测：
- `spec/execute_engine/execute_engine_api.md` -> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/script/test_requirements_txt.py`，通过。
- `kernel_gen/dsl/ast/nodes/nn.py`、`test/dsl/ast/nodes/test_nn.py` -> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/nodes/test_nn.py`，通过。
- `test/dsl/ast/nodes/test_dma.py` -> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/nodes/test_dma.py`，通过。
- `test/dsl/ast/test_mlir_gen.py` -> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/test_mlir_gen.py -k 'globals_cannot_replace_runtime_args or rejects_builtins_external_value_reference'`，通过。
- `test/dsl/gen_kernel/test_gen_kernel.py` -> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/gen_kernel/test_gen_kernel.py -k 'lowered_nn_add or compiles_and_runs_lowered_nn_add_variants_on_cpu'`，通过。
- `test/dsl/gen_kernel/emit/test_package.py` -> `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/gen_kernel/emit/test_package.py -k test_emit_c_op_lowers_mlir_gen_nn_add_variants_after_pass`，通过。
- `spec/dsl/gen_kernel/emit*.md`、`spec/dialect/dma.md`、`spec/include/cpu/cpu.md` 文本口径改动 -> 对应 gen_kernel / emit package / package boundary pytest 已覆盖；这些 spec 改动不计入 expectation。
冲突台账：
- 可直接修复项：requirements 依赖映射缺失 `torch.Tensor`；测试直连 `keepdim_value()` 内部 helper；测试/实现残余 `object` 注解；gen_kernel/emit 旧链路文字。这些已在本轮修复。
- 非违规命中：`open-kind` 是 `spec/pass/tuning/launch_kernel_cost_func.md` 当前公开合同；`build_func_op` 仅作为负向不可达边界保留；静态扫描中的下划线模块路径、公开包导入、测试本地 DSL 函数与公开 API monkeypatch 不是本轮违规。
- 禁止修改项：`expectation/`、`.skills/`、`agents/standard/**`、`AGENTS.md`、`TODO.md`、`DONE.md` 未修改；`expectation` diff empty。
- 阻断项：coverage gate 仍未达到计划硬门禁。按当前 JSON 粗算，`kernel_gen` 约 `146` 个文件有 `14145 / 17959` 行、`4492 / 7202` 分支被覆盖；即使忽略 omit 聚合差异，也至少需要新增约 `2917` 行和 `550` 分支有效覆盖才能达到 `95/70`。最低覆盖集中在 `kernel_gen/passes/lowering/nn_lowering/nn_lowering.py`、`kernel_gen/dsl/ast/plugin/arch.py`、`kernel_gen/dsl/ast/nodes/nn.py`、`kernel_gen/dsl/ast/plugin/nn.py`、`kernel_gen/dsl/ast/nodes/arch.py`、`kernel_gen/operation/nn/broadcast.py`、`kernel_gen/dsl/ast/plugin/dma.py` 等大量模块；这已经超出本轮 conformance 红点修复规模，不能通过计划禁止的 omit、阈值、隐藏测试或删除代码规避。
自检：
- 接口：未新增、删除、重命名或修改公开 API；`mlir_gen` 旧参数测试仍验证公开拒绝行为。
- 边界 / 异常：修复的 requirements 依赖映射通过对应失败测试复现；`globals` / `builtins` 负例仍验证 `TypeError`。
- 兼容性：保留 `build_func_op` 负向不可达边界，不恢复旧公开入口。
- 实现遗漏 / 冗余：本轮仅改 `nn.py` 内部类型注解与 helper 类型别名，没有新增跨文件 helper 依赖；未做大规模覆盖填充以免新增无效测试。
- 注释准确性：清理了旧 `build_func_op` 链路文字，使 spec/test 描述与当前 `mlir_gen -> gen_kernel/emit_c` 入口一致。
- 复用 / 函数粒度：只在当前文件内新增类型别名服务现有内部实现；未拆出新公共接口。
- 输入 / 输出校验：`ExecuteRequest.args` 文档描述与 requirements 检测一致；测试断言仍能在实现错误时失败。
- 资源 / 并发 / 性能：未新增长驻资源、并发逻辑或额外运行时路径。
- 测试有效性：全量 pytest 与 targeted pytest 均通过；coverage gate 真实失败，不作假绿。
结论：当前 execute 未闭合，原因是计划硬门禁 `kernel_gen` coverage `95/70` 失败；已完成可直接修复项和真实自测。需要管理员 / 架构师确认下一步是继续扩大为大规模 coverage 专项实现，还是调整本计划验收口径 / 拆分覆盖率任务；确认前不推进 review。

时间：2026-05-03 14:19 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：记录架构口径并把 coverage gate 计划级冲突转为待用户确认项。
改动：
- 已收到 `守护最好的爱莉希雅` 架构口径：确认前不要推进 review，也不要继续把当前 execute 扩成大规模 coverage 专项。
- 架构判断：当前唯一阻断是计划级 coverage gate `95/70` 与实际改动范围不匹配；`pytest collect/full` 通过、`expectation` diff empty，说明功能 / 公开 API / 禁止修改 expectation 的当前闭环已达成。
- 架构判断：从 `78.44/61.93` 到 `95/70` 需跨大量 `kernel_gen` 模块补约 `2917` 行和 `550` 分支覆盖，超出当前计划可直接落地的小任务卡边界。
- 架构建议：该项写成待用户确认，而不是执行人自行选择；确认前不得降阈值、改 omit、隐藏测试、伪造覆盖，也不得按通过送 review。
验证：
- 本轮未新增代码改动，沿用上一条记录中的 collect/full pytest、coverage gate、静态扫描与 `expectation` diff empty 结果。
- 未执行 `-next`，未推进 review。
- 未修改 `expectation/`、`.skills/`、`agents/standard/**`、`AGENTS.md`、`TODO.md`、`DONE.md`。
待用户确认项：
- 选项 A：保持 `95/70` 作为全仓硬门禁，则当前计划不能 review，需要新建或扩展为独立 coverage 专项计划，明确覆盖模块、测试入口和完成态。
- 选项 B：当前计划调整为目标范围 / Diff 反推 coverage 与公开 API 合同验收通过；全仓 `95/70` 另立后续计划。
自检：已按架构口径停止继续 coverage 扩张和 review 流转；当前记录不改变公开 API、不改变 coverage 阈值、不修改禁止修改面，只把计划级验收冲突落为待用户确认。
结论：T-20260503-9d27254c 维持 execute 待确认状态；等待用户在 A/B 两个选项中确认后再继续。

时间：2026-05-03 14:19 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：记录管理员对 coverage `95/70` 阻塞的最新流转口径。
改动：收到 `神秘人` 管理员口径：T-20260503-9d27254c 的 coverage `95/70` 阻塞已转给两位架构师裁定；裁定前保持 execute，不推进 review；保留当前记录和 worktree 现场。
验证：未运行新测试；本条仅记录流程口径。当前 `git status --short` 显示保留上一轮改动与任务记录目录，未触碰 `expectation/`、`.skills/`、`agents/standard/**`、`AGENTS.md`、`TODO.md`、`DONE.md`。
自检：已停止新增实现 / 测试 / coverage 扩张动作，未执行 `-next`，未推进 review，未修改禁止修改面。
结论：维持 execute 待架构裁定；当前 worktree 现场保留。

时间：2026-05-03 14:20 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：记录 coverage `95/70` 阻塞的架构裁定结论。
改动：收到 `神秘人` 转达的架构裁定：选 B，回到用户调整 / 确认验收口径；确认前不得推进 review。当前阻塞口径固定为：计划验收 coverage `95/70` 硬门禁与实际范围冲突，需要用户确认下一步。
验证：未运行新测试；本条仅记录裁定。当前 `git status --short` 保留上一轮改动与任务记录目录；未触碰 `expectation/`、`.skills/`、`agents/standard/**`、`AGENTS.md`、`TODO.md`、`DONE.md`。
自检：已按裁定保持 execute 阻塞状态，未扩展 coverage 专项，未降阈值，未改 omit，未隐藏测试，未执行 `-next`，未推进 review。
结论：维持 execute 阻塞，等待用户确认验收口径后再继续。

时间：2026-05-03 14:20 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：记录用户对 coverage `95/70` 阻塞的最终裁定，并恢复 execute 补测试。
改动：收到 `守护最好的爱莉希雅` 转达的用户裁定：coverage 不够就完善 test 或添加 test；当前计划继续执行 `95/70` coverage gate，不调整验收、不拆出规避、不进入 review。后续执行要求：优先根据 coverage report 选择低覆盖且可通过公开 API 验证的 `kernel_gen` 模块；禁止直连非公开 API、禁止改 `expectation`、禁止 omit / 降阈值 / 隐藏测试；记录 coverage 前后数据、补测入口和 Diff 反推自测。
验证：未运行新测试；本条只记录裁定并恢复 execute 方向。
自检：已从“等待用户确认”转为继续 execute；后续只补公开 API 测试，不推进 review。
结论：继续 S5 coverage 补测，目标仍为 `kernel_gen` line `95` / branch `70`。

时间：2026-05-03 16:58 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：按用户最新口径改为逐文件 / 逐模块 targeted coverage 推进，不新增 coverage-only 测试文件；把缺口补进当前公开行为测试与对应 spec，并继续维持 `95/70` coverage gate。
改动：
- 收到用户纠偏：不应为覆盖率新建专门 case；应逐文件 / 模块检测覆盖率，在当前 case 增加随机性、补 spec case 与对应实现收口。
- `kernel_gen/dsl/ast/nodes/nn.py`：将内部 `params: list[object]` 和 `target_shape_values: list[object]` 收窄为实际公开值联合类型；未新增公开 API。
- `test/dsl/ast/nodes/test_nn.py`：扩展现有公开 AST 矩阵，覆盖 `Operation` operand、memory/symbol fallback、结构化 `matmul/fc/conv/img2col/softmax/reduce` 成功与稳定错误边界；新增测试入口 `test_nn_emit_mlir_operation_operand_and_result_memory_matrix`，仍只使用公开 AST / Memory / Symbol API。
- `spec/dsl/ast/nodes/nn.md`：同步公开 AST 测试索引，补充 Operation operand、结构化 conv/matmul/fc 错误边界与 result_memory 矩阵。
- `kernel_gen/dsl/ast/nodes/dma.py`：新增当前文件内 `SymbolRuntimeValue` 类型别名，清理本文件局部 `list[object]` 泛化类型；未新增公开 API。
- `test/dsl/ast/nodes/test_dma.py`：扩展现有 result_memory、emit、错误矩阵，覆盖 Operation source/target、动态 alloc shape/stride、copy/cast/view/reshape/flatten/load/store 公开路径与错误边界；新增 `test_dma_flatten_public_dynamic_and_scalar_shape_matrix`。
- `spec/dsl/ast/nodes/dma.md`：同步 DMA AST 测试索引，补充 Operation source/target、动态 flatten shape 与公开错误矩阵。
验证：
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/nodes/test_nn.py`：退出 `0`，`15 passed, 1 warning in 0.78s`。
- `COVERAGE_FILE=/tmp/cov_ast_nn PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --include=kernel_gen/dsl/ast/nodes/nn.py -m pytest -q test/dsl/ast/nodes/test_nn.py && COVERAGE_FILE=/tmp/cov_ast_nn PYTHONDONTWRITEBYTECODE=1 coverage json -o /tmp/cov_ast_nn.json`：退出 `0`，模块覆盖从本轮前 `78.47% line / 64.09% branch` 提升到 `94.80% line / 89.23% branch`，display 为 `95 / 89`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/nodes/test_dma.py`：退出 `0`，`11 passed, 1 warning in 0.54s`。
- `COVERAGE_FILE=/tmp/cov_ast_dma PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --include=kernel_gen/dsl/ast/nodes/dma.py -m pytest -q test/dsl/ast/nodes/test_dma.py && COVERAGE_FILE=/tmp/cov_ast_dma PYTHONDONTWRITEBYTECODE=1 coverage json -o /tmp/cov_ast_dma.json`：退出 `0`，模块覆盖从本轮前 `84.16% line / 78.83% branch` 提升到 `92.58% line / 89.88% branch`，display 为 `93 / 90`。
- `rg -n "object" kernel_gen/dsl/ast/nodes/nn.py kernel_gen/dsl/ast/nodes/dma.py test/dsl/ast/nodes/test_nn.py test/dsl/ast/nodes/test_dma.py`：退出 `1`，确认本轮 touched AST 节点与测试不再残留 `object` 注解文本。
- `python3 -m compileall -q kernel_gen/dsl/ast/nodes/nn.py kernel_gen/dsl/ast/nodes/dma.py test/dsl/ast/nodes/test_nn.py test/dsl/ast/nodes/test_dma.py`：退出 `0`。
Diff 反推自测：
- `kernel_gen/dsl/ast/nodes/nn.py`、`test/dsl/ast/nodes/test_nn.py`、`spec/dsl/ast/nodes/nn.md` -> `pytest -q test/dsl/ast/nodes/test_nn.py` 与 targeted coverage `--include=kernel_gen/dsl/ast/nodes/nn.py`，通过并提升有效覆盖。
- `kernel_gen/dsl/ast/nodes/dma.py`、`test/dsl/ast/nodes/test_dma.py`、`spec/dsl/ast/nodes/dma.md` -> `pytest -q test/dsl/ast/nodes/test_dma.py` 与 targeted coverage `--include=kernel_gen/dsl/ast/nodes/dma.py`，通过并提升有效覆盖。
自检：
- 接口：本轮未新增、删除、重命名或调整公开 API；新增的 `SymbolRuntimeValue` 是当前实现文件内类型别名，仅服务局部实现注解。
- 边界 / 异常：新增断言覆盖公开 AST 的 Operation operand、result_memory unavailable、source/target 非 memory、shape/stride 非 symbol、matmul/fc/conv 错误边界，均会在实现退化时失败。
- 兼容性：未修改 `expectation/`、`.skills/`、`agents/standard/**`、`AGENTS.md`、`TODO.md`、`DONE.md`；未改 pytest / coverage 配置、omit 或阈值。
- 实现遗漏 / 冗余：按用户口径清理了本轮 touched AST 文件中的 `object` 泛化注解；未为了覆盖率直连私有 helper 或新增专用覆盖率文件。
- 测试有效性：新增测试全部走 spec 定义公开 AST / Memory / Symbol 入口；targeted coverage 前后数据证明补测有效。
结论：逐模块推进方式已切换并产生有效提升；全量 `kernel_gen` coverage gate 尚未复跑，下一步继续按 coverage report 选择下一个低覆盖公开模块补现有测试 / spec。

时间：2026-05-03 20:05 +0800
经办人：金铲铲大作战
任务：T-20260503-9d27254c / repo-spec-test-conformance
任务目标：按用户口径继续逐文件 / 模块补公开行为测试，达成 `kernel_gen` coverage `95/70` 硬门禁，并在回 review 前执行最新主线同步检查。
改动：
- `kernel_gen/dsl/gen_kernel/emit/npu_demo/tuner/cost.py`：删除 `kernel.img2col1d` / `kernel.img2col2d` 在严格 operand 数量校验后的不可达 `symbol_values` 空分支；未新增或调整公开 API。
- `test/dsl/gen_kernel/emit/test_package.py`：扩展现有 npu_demo tuner cost 公开错误矩阵，覆盖 `select/reduce/dma.copy/dma.slice/matmul/img2col1d/img2col2d` 的 operand arity、memory 类型与 space mismatch 边界；未直连私有 helper。
- `test/dsl/ast/plugin/test_arch.py`：扩展现有 arch plugin 公开 parser 用例，补 list/tuple barrier、SymbolDim launch extents、literal/expr 混用错误和随机非法合同矩阵。
- `spec/dsl/ast/plugin/arch.md`：同步 `test_arch.py` 新增公开 parser 行为索引。
- `test/tools/test_dsl_run.py`：扩展现有 `dsl_run(...)` 公开入口用例，覆盖空函数名 dump fallback、自定义公开 `PassManager` dump fallback、pipeline 清空 target 后拒绝、unsupported numpy dtype 与 `bfloat16` dtype 映射边界。
- `spec/tools/dsl_run.md`：补 `TC-TOOLS-DSL-RUN-031` 至 `TC-TOOLS-DSL-RUN-035` 的公开用例索引。
- `kernel_gen/passes/memory_pool.py`：删除当前文件内未使用的 `_dtype_string(...)` / `_collect_ops(...)` 私有实现；新增当前文件内私有 `_free_indices_for_ops(...)` / `_alloc_infos_from_ops(...)`，收敛 summary 与 rewrite 的重复 alloc/free 生命周期校验；删除 `_peak_bytes(...)` 与 rewrite slot 分配中的不可达防御分支。公开 API 列表不变。
- `test/passes/test_memory_pool.py`：扩展现有 `MemoryPoolPass.apply(...)` 公开行为测试，补 unsupported integer width、匿名 stride、重复 `dma.free` 与 `rewrite=True` 非 alloc no-op 边界。
- `spec/pass/lowering/memory_pool.md`：补 `TC-PASS-LOWERING-MEMORY-POOL-020` / `021`，同步新增公开测试索引。
coverage 前后数据：
- 阶段前全量门禁：`COVERAGE_FILE=/tmp/cov_repo_spec_conformance_after_batch ... pytest -q test` 结果为 `1814 passed, 29 warnings in 317.79s`；`check_python_coverage.py --line-min 95 --branch-min 70` 失败，摘要为 line `94.41% < 95.00%`，branch 已通过。
- 阶段后全量门禁：`COVERAGE_FILE=/tmp/cov_repo_spec_conformance_after_more PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --source=kernel_gen -m pytest -q test && COVERAGE_FILE=/tmp/cov_repo_spec_conformance_after_more coverage json -o /tmp/cov_repo_spec_conformance_after_more.json && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. python3 script/check_python_coverage.py --coverage-json /tmp/cov_repo_spec_conformance_after_more.json --line-min 95 --branch-min 70`：退出 `0`，`1829 passed, 29 warnings in 319.69s`，`coverage ok: scope=totals; line=95.11% >= 95.00%; branch=87.91% >= 70.00%`。
- JSON totals：`covered_lines=15948 / num_statements=16792`，`covered_branches=5702 / num_branches=6504`；以 gate 脚本口径通过 `95/70`。
补测模块定向数据：
- `kernel_gen/dsl/gen_kernel/emit/npu_demo/tuner/cost.py`：阶段前 `213/244` 行、`87.30%`；阶段后 `240/240` 行、`100.00%`，branch `132/132`、`100.00%`。
- `kernel_gen/dsl/ast/plugin/arch.py`：阶段前 `134/157` 行、`85.35%`，branch `60/80`、`75.00%`；阶段后 `146/157` 行、`92.99%`，branch `71/80`、`88.75%`。
- `kernel_gen/tools/dsl_run.py`：阶段前 `167/187` 行、`89.30%`，branch `48/58`、`82.76%`；阶段后 `182/187` 行、`97.33%`，branch `53/58`、`91.38%`。
- `kernel_gen/passes/memory_pool.py`：阶段前 `402/446` 行、`90.13%`，branch `162/202`、`80.20%`；阶段后 `373/390` 行、`95.64%`，branch `143/160`、`89.38%`。
验证：
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/gen_kernel/emit/test_package.py -k "npu_demo_tuner_cost"`：退出 `0`，`11 passed, 48 deselected, 1 warning`。
- `COVERAGE_FILE=/tmp/cov_tuner_cost_after2 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --include=kernel_gen/dsl/gen_kernel/emit/npu_demo/tuner/cost.py -m pytest -q test/dsl/gen_kernel/emit/test_package.py -k "npu_demo_tuner_cost" && COVERAGE_FILE=/tmp/cov_tuner_cost_after2 coverage json -o /tmp/cov_tuner_cost_after2.json`：退出 `0`，目标文件 `100.00% / 100.00%`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/dsl/ast/plugin/test_arch.py`：退出 `0`，`38 passed, 1 warning`。
- `COVERAGE_FILE=/tmp/cov_plugin_arch_after PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --include=kernel_gen/dsl/ast/plugin/arch.py -m pytest -q test/dsl/ast/plugin/test_arch.py && COVERAGE_FILE=/tmp/cov_plugin_arch_after coverage json -o /tmp/cov_plugin_arch_after.json`：退出 `0`，目标文件 `92.99% / 88.75%`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/tools/test_dsl_run.py -k "empty_function_name or custom_pipeline_dump or target_cleared or unsupported_numpy_dtype or bfloat16"`：退出 `0`，`5 passed, 27 deselected, 1 warning`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/tools/test_dsl_run.py`：退出 `0`，`32 passed, 1 warning`。
- `COVERAGE_FILE=/tmp/cov_dsl_run_after PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --include=kernel_gen/tools/dsl_run.py -m pytest -q test/tools/test_dsl_run.py && COVERAGE_FILE=/tmp/cov_dsl_run_after coverage json -o /tmp/cov_dsl_run_after.json`：退出 `0`，目标文件 `97.33% / 91.38%`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. pytest -q test/passes/test_memory_pool.py`：退出 `0`，`21 passed, 5 warnings`。
- `COVERAGE_FILE=/tmp/cov_memory_pool_more PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. coverage run --branch --include=kernel_gen/passes/memory_pool.py -m pytest -q test/passes/test_memory_pool.py && COVERAGE_FILE=/tmp/cov_memory_pool_more coverage json -o /tmp/cov_memory_pool_more.json`：退出 `0`，目标文件 `95.64% / 89.38%`。
- `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. python3 -m compileall -q kernel_gen/passes/memory_pool.py test/passes/test_memory_pool.py kernel_gen/dsl/gen_kernel/emit/npu_demo/tuner/cost.py test/dsl/gen_kernel/emit/test_package.py test/dsl/ast/plugin/test_arch.py test/tools/test_dsl_run.py`：退出 `0`。
- `git diff --name-only -- expectation`：退出 `0`，输出为空，确认未修改 `expectation/`。
- `git diff -- test | rg -n "collect_ignore|pytest_ignore_collect|skip\\(|xfail|pytest\\.mark\\.skip|pytest\\.mark\\.xfail"`：退出 `1`，无命中，确认未新增 skip / xfail / collect hidden。
- `rg -n "hasattr\\([^)]*ctx|getattr\\([^)]*ctx" test kernel_gen script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `1`，无命中。
- `rg -n "def [A-Za-z0-9_]+\\([^)]*: object|-> object" kernel_gen test script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `1`，无命中。
- `rg -n "from kernel_gen\\..* import .*_[A-Za-z]|kernel_gen\\.[A-Za-z0-9_.]*\\._[A-Za-z]" test script main.py skills/codex-multi-agents/scripts -g "*.py"`：退出 `0`，剩余命中均为公开模块路径含下划线、公开包导入、旧路径不可达负向测试或既有公开入口导入；本阶段新增测试未直连跨文件非公开 helper。
- `git diff -- pytest.ini pyproject.toml setup.cfg tox.ini .coveragerc spec script test kernel_gen | rg -n "addopts|testpaths|markers|filterwarnings|norecursedirs|collect_ignore|pytest_ignore_collect|line-min|branch-min|coverage_omit|python_coverage_omit|omit|--include-module|95|70"`：退出 `0`，命中为 diff hunk 行号、index 文本与既有 `python_coverage_omit` 文件删除项上下文；本阶段未改 pytest / coverage 配置、omit、阈值或 include 范围。
- `git diff --check`：退出 `0`。
Diff 反推自测：
- `kernel_gen/dsl/gen_kernel/emit/npu_demo/tuner/cost.py`、`test/dsl/gen_kernel/emit/test_package.py` -> `pytest -q test/dsl/gen_kernel/emit/test_package.py -k "npu_demo_tuner_cost"` 与 targeted coverage，均通过。
- `test/dsl/ast/plugin/test_arch.py`、`spec/dsl/ast/plugin/arch.md` -> `pytest -q test/dsl/ast/plugin/test_arch.py` 与 targeted coverage，均通过。
- `test/tools/test_dsl_run.py`、`spec/tools/dsl_run.md` -> `pytest -q test/tools/test_dsl_run.py` 与 targeted coverage，均通过。
- `kernel_gen/passes/memory_pool.py`、`test/passes/test_memory_pool.py`、`spec/pass/lowering/memory_pool.md` -> `pytest -q test/passes/test_memory_pool.py` 与 targeted coverage，均通过。
- 全量计划门禁 -> `coverage run --branch --source=kernel_gen -m pytest -q test` + `check_python_coverage.py --line-min 95 --branch-min 70`，通过。
自检：
- 接口：未新增、删除、重命名或调整公开 API；新增 helper 均在当前文件内且以下划线私有命名服务现有 spec API。
- 边界 / 异常：新增断言覆盖 tuner cost operand/memory/space 错误、arch parser literal/expr 错误、dsl_run dump/target/dtype 边界、memory_pool dtype/stride/lifetime/no-op 边界。
- 兼容性：未修改 `expectation/`、`.skills/`、`agents/standard/**`、`AGENTS.md`、`TODO.md`、`DONE.md`；未改 pytest / coverage 配置、omit 或阈值。
- 实现遗漏 / 冗余：`memory_pool` 已收敛重复生命周期校验并删除未使用私有实现；`tuner cost` 删除严格校验后的不可达分支。
- 注释准确性：修改实现文件未改变公开 API 列表；新增 / 修改 spec 行仅同步当前公开测试索引。
- 复用 / 函数粒度：只在当前文件内复用私有 helper，未跨文件调用非公开 API。
- 输入 / 输出校验：新增测试均通过公开 API 构造输入并断言公开错误语义，不依赖隐藏 helper。
- 资源 / 并发 / 性能：未新增外部资源、并发路径或长驻状态。
- 测试有效性：新增测试能提升对应目标模块覆盖，并在全量 coverage gate 中贡献有效覆盖；没有新增 skip/xfail/collect hidden。
主线同步检查：
- `git fetch origin`：退出 `0`。
- 同步基线检查：`HEAD=3a79bec435e2b573a5c1bda51fbf339c8a56b13b`，`origin/main=053f7e911a10a108b24df0ee61f6456491d73c9f`，`merge-base=3a79bec435e2b573a5c1bda51fbf339c8a56b13b`，说明最新主线已前进。
- `git diff --name-only HEAD..origin/main` 显示 upstream 涉及 `kernel_gen/tools/dsl_run.py`、`test/tools/test_dsl_run.py`、`test/dsl/gen_kernel/emit/test_package.py`、`spec/tools/dsl_run.md` 等相关文件。
- `comm -12 <(git diff --name-only HEAD..origin/main | sort) <(git status --short | awk '{print $2}' | sort)` 显示与当前任务本地 diff 重叠的文件包括 `spec/dialect/dma.md`、`spec/dialect/kernel.md`、`spec/dialect/nn.md`、`spec/dialect/symbol.md`、`spec/dsl/ast/dsl_ast.md`、`spec/dsl/ast/mlir_gen.md`、`spec/dsl/ast/nodes/symbol.md`、`spec/dsl/gen_kernel/emit.md`、`spec/dsl/gen_kernel/emit/npu_demo/dma/__init__.md`、`spec/dsl/gen_kernel/emit/npu_demo/symbol/__init__.md`、`spec/execute_engine/execute_engine_target.md`、`spec/tools/dsl_run.md`、`test/dialect/test_dma.py`、`test/dialect/test_kernel.py`、`test/dialect/test_symbol.py`、`test/dsl/ast/nodes/test_symbol.py`、`test/dsl/ast/test_mlir_gen.py`、`test/dsl/gen_kernel/emit/test_package.py`、`test/execute_engine/test_compile.py`、`test/tools/test_dsl_run.py`。
阻塞：
- 根据用户最新“待审前必须先对齐最新主线现场”的流程，当前 worktree 有大量未提交任务 diff，且 `origin/main` 前进提交与本地任务 diff 存在多文件重叠；强行 merge / checkout / reset 可能覆盖或冲突任务改动。
- 已按流程停止推进 review，未执行 `-next`，需要管理员 / 架构师确认如何安全同步该 dirty worktree 到 `origin/main@053f7e911a10a108b24df0ee61f6456491d73c9f` 后再复跑验收。
结论：功能实现、公开 pytest 与 coverage `95/70` 硬门禁已闭合；当前唯一阻塞是待 review 前主线同步存在本地 diff 重叠风险，已暂停等待管理员处理口径。
